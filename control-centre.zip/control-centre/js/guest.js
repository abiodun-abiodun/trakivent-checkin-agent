// =====================================
// TRAKIVENT
// Guest Module
// Version 1.0
// =====================================

async function checkinGuest(token){

    try{

        const data =
            await apiCheckin(token);

        if(data.success){

            await refreshDashboard();

            await searchGuest(token);

        }else{

            alert(data.message || "Unable to check in guest.");

        }

    }

    catch(error){

        console.error("Checkin:", error);

    }

}

async function undoGuest(token){

    try{

        const data =
            await apiUndo(token);

        if(data.success){

            await refreshDashboard();

            await searchGuest(token);

        }else{

            alert(data.message || "Unable to undo check-in.");

        }

    }

    catch(error){

        console.error("Undo:", error);

    }

}